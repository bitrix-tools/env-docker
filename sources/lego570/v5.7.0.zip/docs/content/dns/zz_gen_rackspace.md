---
title: "Rackspace"
date: 2019-03-03T16:39:46+01:00
draft: false
slug: rackspace
dnsprovider:
  since:    "v0.4.0"
  code:     "rackspace"
  url:      "https://www.rackspace.com/"
---

<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
<!-- providers/dns/rackspace/rackspace.toml -->
<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->


Configuration for [Rackspace](https://www.rackspace.com/).


<!--more-->

- Code: `rackspace`
- Since: v0.4.0


Here is an example bash command using the Rackspace provider:

```bash
RACKSPACE_USER=xxxx \
RACKSPACE_API_KEY=yyyy \
lego run --dns rackspace -d '*.example.com' -d example.com
```




## Credentials

| Environment Variable Name | Description |
|-----------------------|-------------|
| `RACKSPACE_API_KEY` | API key |
| `RACKSPACE_USER` | API user |

The environment variable names can be suffixed by `_FILE` to reference a file instead of a value.
More information [here]({{% ref "dns#configuration-and-credentials" %}}).


## Additional Configuration

| Environment Variable Name | Description |
|--------------------------------|-------------|
| `RACKSPACE_HTTP_TIMEOUT` | API request timeout in seconds (Default: 30) |
| `RACKSPACE_POLLING_INTERVAL` | Time between DNS propagation check in seconds (Default: 3) |
| `RACKSPACE_PROPAGATION_TIMEOUT` | Maximum waiting time for DNS propagation in seconds (Default: 60) |
| `RACKSPACE_TTL` | The TTL of the TXT record used for the DNS challenge in seconds (Default: 300) |

The environment variable names can be suffixed by `_FILE` to reference a file instead of a value.
More information [here]({{% ref "dns#configuration-and-credentials" %}}).




## More information

- [API documentation](https://docs.rackspace.com/reference/cloud-dns-api-reference)

<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
<!-- providers/dns/rackspace/rackspace.toml -->
<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
