---
title: "mijn.host"
date: 2019-03-03T16:39:46+01:00
draft: false
slug: mijnhost
dnsprovider:
  since:    "v4.18.0"
  code:     "mijnhost"
  url:      "https://mijn.host/"
---

<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
<!-- providers/dns/mijnhost/mijnhost.toml -->
<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->


Configuration for [mijn.host](https://mijn.host/).


<!--more-->

- Code: `mijnhost`
- Since: v4.18.0


Here is an example bash command using the mijn.host provider:

```bash
MIJNHOST_API_KEY="xxxxxxxxxxxxxxxxxxxxx" \
lego run --dns mijnhost -d '*.example.com' -d example.com
```




## Credentials

| Environment Variable Name | Description |
|-----------------------|-------------|
| `MIJNHOST_API_KEY` | The API key |

The environment variable names can be suffixed by `_FILE` to reference a file instead of a value.
More information [here]({{% ref "dns#configuration-and-credentials" %}}).


## Additional Configuration

| Environment Variable Name | Description |
|--------------------------------|-------------|
| `MIJNHOST_HTTP_TIMEOUT` | API request timeout in seconds (Default: 30) |
| `MIJNHOST_POLLING_INTERVAL` | Time between DNS propagation check in seconds (Default: 2) |
| `MIJNHOST_PROPAGATION_TIMEOUT` | Maximum waiting time for DNS propagation in seconds (Default: 60) |
| `MIJNHOST_SEQUENCE_INTERVAL` | Time between sequential requests in seconds (Default: 60) |
| `MIJNHOST_TTL` | The TTL of the TXT record used for the DNS challenge in seconds (Default: 120) |

The environment variable names can be suffixed by `_FILE` to reference a file instead of a value.
More information [here]({{% ref "dns#configuration-and-credentials" %}}).




## More information

- [API documentation](https://mijn.host/api/doc/)

<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
<!-- providers/dns/mijnhost/mijnhost.toml -->
<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
