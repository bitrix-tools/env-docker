---
title: "DanDomain"
date: 2019-03-03T16:39:46+01:00
draft: false
slug: dandomain
dnsprovider:
  since:    "v5.0.0"
  code:     "dandomain"
  url:      "https://dandomain.dk/"
---

<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
<!-- providers/dns/dandomain/dandomain.toml -->
<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->


Configuration for [DanDomain](https://dandomain.dk/).


<!--more-->

- Code: `dandomain`
- Since: v5.0.0


Here is an example bash command using the DanDomain provider:

```bash
DANDOMAIN_CLIENT_ID="xxx" \
DANDOMAIN_CLIENT_SECRET="yyy" \
lego run --dns dandomain -d '*.example.com' -d example.com
```




## Credentials

| Environment Variable Name | Description |
|-----------------------|-------------|
| `DANDOMAIN_CLIENT_ID` | Client ID |
| `DANDOMAIN_CLIENT_SECRET` | Client secret |

The environment variable names can be suffixed by `_FILE` to reference a file instead of a value.
More information [here]({{% ref "dns#configuration-and-credentials" %}}).


## Additional Configuration

| Environment Variable Name | Description |
|--------------------------------|-------------|
| `DANDOMAIN_HTTP_TIMEOUT` | API request timeout in seconds (Default: 30) |
| `DANDOMAIN_POLLING_INTERVAL` | Time between DNS propagation check in seconds (Default: 2) |
| `DANDOMAIN_PROPAGATION_TIMEOUT` | Maximum waiting time for DNS propagation in seconds (Default: 60) |
| `DANDOMAIN_TTL` | The TTL of the TXT record used for the DNS challenge in seconds (Default: 120) |

The environment variable names can be suffixed by `_FILE` to reference a file instead of a value.
More information [here]({{% ref "dns#configuration-and-credentials" %}}).




## More information

- [API documentation](https://api.dandomain.dk/dns/swagger/index.html)

<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
<!-- providers/dns/dandomain/dandomain.toml -->
<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
