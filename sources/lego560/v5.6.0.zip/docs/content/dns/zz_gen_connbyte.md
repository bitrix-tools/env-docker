---
title: "Connbyte"
date: 2019-03-03T16:39:46+01:00
draft: false
slug: connbyte
dnsprovider:
  since:    "v5.1.0"
  code:     "connbyte"
  url:      "https://connbyte.com/"
---

<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
<!-- providers/dns/connbyte/connbyte.toml -->
<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->


Configuration for [Connbyte](https://connbyte.com/).


<!--more-->

- Code: `connbyte`
- Since: v5.1.0


Here is an example bash command using the Connbyte provider:

```bash
CONNBYTE_TOKEN="xxxxxxxxxxxxxxxxxxxxx" \
lego run --dns connbyte -d '*.example.com' -d example.com
```




## Credentials

| Environment Variable Name | Description |
|-----------------------|-------------|
| `CONNBYTE_TOKEN` | Token |

The environment variable names can be suffixed by `_FILE` to reference a file instead of a value.
More information [here]({{% ref "dns#configuration-and-credentials" %}}).


## Additional Configuration

| Environment Variable Name | Description |
|--------------------------------|-------------|
| `CONNBYTE_HTTP_TIMEOUT` | API request timeout in seconds (Default: 30) |
| `CONNBYTE_POLLING_INTERVAL` | Time between DNS propagation check in seconds (Default: 2) |
| `CONNBYTE_PROPAGATION_TIMEOUT` | Maximum waiting time for DNS propagation in seconds (Default: 60) |
| `CONNBYTE_TTL` | The TTL of the TXT record used for the DNS challenge in seconds (Default: 120) |

The environment variable names can be suffixed by `_FILE` to reference a file instead of a value.
More information [here]({{% ref "dns#configuration-and-credentials" %}}).




## More information

- [API documentation](https://api.connbyte.com/)

<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
<!-- providers/dns/connbyte/connbyte.toml -->
<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
