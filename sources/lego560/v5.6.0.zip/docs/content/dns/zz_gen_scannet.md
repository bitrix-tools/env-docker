---
title: "ScanNet"
date: 2019-03-03T16:39:46+01:00
draft: false
slug: scannet
dnsprovider:
  since:    "v5.0.0"
  code:     "scannet"
  url:      "https://www.scannet.dk/"
---

<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
<!-- providers/dns/scannet/scannet.toml -->
<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->


Configuration for [ScanNet](https://www.scannet.dk/).


<!--more-->

- Code: `scannet`
- Since: v5.0.0


Here is an example bash command using the ScanNet provider:

```bash
SCANNET_CLIENT_ID="xxx" \
SCANNET_CLIENT_SECRET="yyy" \
lego run --dns scannet -d '*.example.com' -d example.com
```




## Credentials

| Environment Variable Name | Description |
|-----------------------|-------------|
| `SCANNET_CLIENT_ID` | Client ID |
| `SCANNET_CLIENT_SECRET` | Client secret |

The environment variable names can be suffixed by `_FILE` to reference a file instead of a value.
More information [here]({{% ref "dns#configuration-and-credentials" %}}).


## Additional Configuration

| Environment Variable Name | Description |
|--------------------------------|-------------|
| `SCANNET_HTTP_TIMEOUT` | API request timeout in seconds (Default: 30) |
| `SCANNET_POLLING_INTERVAL` | Time between DNS propagation check in seconds (Default: 2) |
| `SCANNET_PROPAGATION_TIMEOUT` | Maximum waiting time for DNS propagation in seconds (Default: 60) |
| `SCANNET_TTL` | The TTL of the TXT record used for the DNS challenge in seconds (Default: 120) |

The environment variable names can be suffixed by `_FILE` to reference a file instead of a value.
More information [here]({{% ref "dns#configuration-and-credentials" %}}).




## More information

- [API documentation](https://api.scannet.dk/dns/swagger/index.html)

<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
<!-- providers/dns/scannet/scannet.toml -->
<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
