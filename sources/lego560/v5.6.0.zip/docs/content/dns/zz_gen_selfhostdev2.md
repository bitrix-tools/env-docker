---
title: "SelfHost.(de|eu)"
date: 2019-03-03T16:39:46+01:00
draft: false
slug: selfhostdev2
dnsprovider:
  since:    "v5.6.0"
  code:     "selfhostdev2"
  url:      "https://www.selfhost.de"
---

<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
<!-- providers/dns/selfhostdev2/selfhostdev2.toml -->
<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->


Configuration for [SelfHost.(de|eu)](https://www.selfhost.de).


<!--more-->

- Code: `selfhostdev2`
- Since: v5.6.0


Here is an example bash command using the SelfHost.(de|eu) provider:

```bash
SELFHOSTDEV2_API_KEYS="example.com:xx.yy,example.org:ww.zz" \
SELFHOSTDEV2_RECORDS_MAPPING=my.example.com:123 \
lego run --dns selfhostdev2 -d '*.example.com' -d example.com
```




## Credentials

| Environment Variable Name | Description |
|-----------------------|-------------|
| `SELFHOSTDEV2_API_KEYS` | API keys mapping with domains (ex: example.com:xx.yy,example.org:ww.zz). |
| `SELFHOSTDEV2_RECORDS_MAPPING` | Record IDs mapping with domains (ex: example.com:123:456,example.org:789,foo.example.com:147). |

The environment variable names can be suffixed by `_FILE` to reference a file instead of a value.
More information [here]({{% ref "dns#configuration-and-credentials" %}}).


## Additional Configuration

| Environment Variable Name | Description |
|--------------------------------|-------------|
| `SELFHOSTDEV2_HTTP_TIMEOUT` | API request timeout in seconds (Default: 30) |
| `SELFHOSTDEV2_POLLING_INTERVAL` | Time between DNS propagation check in seconds (Default: 30) |
| `SELFHOSTDEV2_PROPAGATION_TIMEOUT` | Maximum waiting time for DNS propagation in seconds (Default: 240) |
| `SELFHOSTDEV2_TTL` | The TTL of the TXT record used for the DNS challenge in seconds (Default: 120) |

The environment variable names can be suffixed by `_FILE` to reference a file instead of a value.
More information [here]({{% ref "dns#configuration-and-credentials" %}}).

SelfHost.de has a complex API to create or delete TXT records:

before using lego to request a certificate for a given domain or wildcard (such as `my.example.org` or `*.my.example.org`),
you must create:

- one TXT record named `_acme-challenge.my.example.org` if you are **not** using wildcard for this domain.
- two TXT records named `_acme-challenge.my.example.org` if you are using wildcard for this domain.

After that you must edit the TXT record(s) to get the ID(s).

You then must prepare the `SELFHOSTDE_RECORDS_MAPPING` environment variable with the following format:

```
<domain_A>:<record_id_A1>:<record_id_A2>,<domain_B>:<record_id_B1>:<record_id_B2>,<domain_C>:<record_id_C1>:<record_id_C2>
```

where each group of domain + record ID(s) is separated with a comma (`,`),
and the domain and record ID(s) are separated with a colon (`:`).

For example, if you want to create or renew a certificate for `my.example.org`, `*.my.example.org`, and `other.example.org`,
you would need:

- two separate records for `_acme-challenge.my.example.org`
- and another separate record for `_acme-challenge.other.example.org`

The resulting environment variable would then be: `SELFHOSTDE_RECORDS_MAPPING=my.example.com:123:456,other.example.com:789`

Also, the API keys are per domain.

You must prepare the `SELFHOSTDE_API_KEYS` environment variable with the following format:

```
<domain_X>:<API_key_1>,<domain_Y>:<API_key_2>,<domain_Z>:<API_key_3>
```

The API key format is `<key_id>.<secret>`, where `key_id` is numeric (no leading zero), `secret` is lowercase hex characters.





<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
<!-- providers/dns/selfhostdev2/selfhostdev2.toml -->
<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
