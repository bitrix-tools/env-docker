---
title: "Glesys"
date: 2019-03-03T16:39:46+01:00
draft: false
slug: glesys
dnsprovider:
  since:    "v0.5.0"
  code:     "glesys"
  url:      "https://glesys.com/"
---

<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
<!-- providers/dns/glesys/glesys.toml -->
<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->


Configuration for [Glesys](https://glesys.com/).


<!--more-->

- Code: `glesys`
- Since: v0.5.0


Here is an example bash command using the Glesys provider:

```bash
GLESYS_API_USER=xxxxx \
GLESYS_API_KEY=yyyyy \
lego run --dns glesys -d '*.example.com' -d example.com
```




## Credentials

| Environment Variable Name | Description |
|-----------------------|-------------|
| `GLESYS_API_KEY` | API key |
| `GLESYS_API_USER` | API user |

The environment variable names can be suffixed by `_FILE` to reference a file instead of a value.
More information [here]({{% ref "dns#configuration-and-credentials" %}}).


## Additional Configuration

| Environment Variable Name | Description |
|--------------------------------|-------------|
| `GLESYS_HTTP_TIMEOUT` | API request timeout in seconds (Default: 10) |
| `GLESYS_POLLING_INTERVAL` | Time between DNS propagation check in seconds (Default: 20) |
| `GLESYS_PROPAGATION_TIMEOUT` | Maximum waiting time for DNS propagation in seconds (Default: 1200) |
| `GLESYS_TTL` | The TTL of the TXT record used for the DNS challenge in seconds (Default: 60) |

The environment variable names can be suffixed by `_FILE` to reference a file instead of a value.
More information [here]({{% ref "dns#configuration-and-credentials" %}}).




## More information

- [API documentation](https://github.com/GleSYS/API/wiki/API-Documentation)

<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
<!-- providers/dns/glesys/glesys.toml -->
<!-- THIS DOCUMENTATION IS AUTO-GENERATED. PLEASE DO NOT EDIT. -->
