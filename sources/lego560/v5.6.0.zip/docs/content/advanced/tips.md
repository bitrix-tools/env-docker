---
title: "Tips"
date: 2019-03-03T16:39:46+01:00
draft: false
weight: 8
---

This section contains some tips and tricks for using lego.

<!--more-->

## Automatic Renewal

It is tempting to create a cron job (or systemd timer) to automatically renew all you certificates.

When doing so, please note that some cron defaults will cause a measurable load on the ACME provider's infrastructure.
Notably `@daily` jobs run at midnight.

To both counteract load spikes (caused by all lego users) and reduce subsequent renewal failures, we were asked to implement a small random delay for non-interactive renewals.[^loadspikes]
Since v4.8.0, lego will pause for up to 8 minutes to help spread the load.

You can help further, by adjusting your crontab entry, like so:

```ruby
# avoid:
#@daily      /usr/bin/lego ...
#@midnight   /usr/bin/lego ...
#0 0 * * *   /usr/bin/lego ...

# instead, use a randomly chosen time:
35 3 * * *  /usr/bin/lego ...
```

If you use systemd timers, consider doing something similar, and/or introduce a `RandomizedDelaySec`:

```ini
[Unit]
Description=Renew certificates

[Timer]
Persistent=true
# avoid:
#OnCalendar=*-*-* 00:00:00
#OnCalendar=daily

# instead, use a randomly chosen time:
OnCalendar=*-*-* 3:35
# add extra delay, here up to 1 hour:
RandomizedDelaySec=1h

[Install]
WantedBy=timers.target
```

[^loadspikes]: See [GitHub issue #1656](https://github.com/go-acme/lego/issues/1656) for an excellent problem description.

## Running without root privileges

The CLI does not require root permissions but needs to bind to port 80 and 443 for certain challenges.
To run the CLI without `sudo`, you have four options:

- Use `setcap 'cap_net_bind_service=+ep' /path/to/lego` (Linux only)
- Pass the `--http.address` or/and the `--tls.address` option and specify a custom port to bind to. In this case you have to forward port 80/443 to these custom ports (see [Port Usage](#port-usage)).
- Pass the `--http.webroot` option and specify the path to your webroot folder. In this case the challenge will be written in a file in `.well-known/acme-challenge/` inside your webroot.
- Pass the `--dns` option and specify a DNS provider.

## Port Usage

By default, lego assumes it is able to bind to ports 80 and 443 to solve challenges.
If this is not possible in your environment, you can use the `--http.address` and `--tls.address` options to instruct
lego to listen on that interface:port for any incoming challenges.

If you are using either of these options, make sure you setup a proxy to redirect traffic to the chosen ports.

**HTTP Port:** All plaintext HTTP requests to port **80** which begin with a request path of `/.well-known/acme-challenge/` for the HTTP challenge[^header].

**TLS Port:** All TLS handshakes on port **443** for the TLS-ALPN challenge.

This traffic redirection is only needed as long as lego solves challenges. As soon as you have received your certificates you can deactivate the forwarding.

[^header]: You must ensure that incoming validation requests contains the correct value for the HTTP `Host` header. If you operate lego behind a non-transparent reverse proxy (such as Apache or NGINX), you might need to alter the header field using `--http.proxy-header X-Forwarded-Host`.

## DNS Resolvers and Challenge Verification

When using a DNS challenge provider (via `--dns <name>`), Lego tries to ensure the ACME challenge token is properly setup before instructing the ACME provider to perform the validation.

This involves a few DNS queries to different servers:

1. Determining the DNS zone and resolving CNAMEs.

   The DNS zone for a given domain is determined by the SOA record, which contains the authoritative name server for the domain and all its subdomains.
   For simple domains like `example.com`, this is usually `example.com` itself.
   For other domains (like `fra.eu.cdn.example.com`), this can get complicated, as `cdn.example.com` may be delegated to the CDN provider, which means for `cdn.example.com` must exist a different SOA record.

   To find the correct zone, Lego requests the SOA record for each DNS label (starting on the leaf domain, i.e. the left-most DNS label).
   If there is no SOA record, Lego requests the SOA record of the parent label, then for its parent, etc., until it reaches the apex domain[^apex].
   Should any DNS label on the way be a CNAME, it is resolved as per usual.

   In the default configuration, Lego uses the system name servers for this, and falls back to Cloudflare's DNS servers, should they be absent.

2. Verifying the challenge token.

   The `_acme-challenge.<yourdomain>` TXT record must be correctly installed.
   Lego verifies this by directly querying the authoritative name server for this record (as detected in the previous step).

Strictly speaking, this verification step is not necessary, but helps to protect your ACME account.
Remember that some ACME providers impose a rate limit on certain actions (at the time of writing, Let's Encrypt allows 300 new certificate orders per account per 3 hours).

There are also situations where this verification step doesn't work as expected:

- A "split DNS" setup gives different answers to clients on the internal network (Lego) vs. on the public internet (ACME server).
- With "hidden master" setups, Lego may be able to directly talk to the primary DNS server, while the `_acme-challenge` record might not have fully propagated to the (public) secondary servers, yet.

The effect is the same: Lego determined the challenge token to be installed correctly, while the ACME server has a different view and rejects the certificate order.

In these cases, you can instruct Lego to use a different DNS resolver, using the `--dns.resolvers` flag.
You should prefer one on the public internet, otherwise you might be susceptible to the same problem.

[^apex]: The apex domain is the domain you have registered with your domain registrar. For gTLDs (`.com`, `.fyi`) this is the 2nd level domain, but for ccTLDs, this can either be the 2nd level (`.de`) or 3rd level domain (`.co.uk`).

## Conditional DNS Build

This feature is experimental.

By default, lego includes all DNS providers.
If you only need one or a few of them, you can leave the others out at build time.

This makes the result considerably smaller and cuts the number of dependencies (and with it, the noise from vulnerability scanners).

It is controlled by build tags:
- `lego_dnslight` enables the feature. Without it, all `lego_dns_*` tags are ignored and all DNS providers are included.
- `lego_dns_<code>` includes a DNS provider, where `<code>` is the name you pass to `--dns`, e.g. `lego_dns_cloudflare` or `lego_dns_pdns`.

Selecting a DNS provider that was not included fails at runtime, not at compile time.

### Building the lego binary

From a clone of the repository, the `build_dnslight` target adds `lego_dnslight` for you:

```bash
# Only one provider:
make build_dnslight DNS="lego_dns_cloudflare"

# Several providers:
make build_dnslight DNS="lego_dns_cloudflare,lego_dns_pdns"
```

Without a clone, use `go install`:

```bash
go install -tags lego_dnslight,lego_dns_cloudflare,lego_dns_pdns github.com/go-acme/lego/v5@latest
```

`lego dnshelp` lists the DNS providers included in a binary.

### Using lego as a library

The build tags only change `dns.NewDNSChallengeProviderByName()`, i.e. when your application selects the DNS provider by name at runtime.

If you create the provider directly (e.g. `cloudflare.NewDNSProvider()`), 
Go only compiles in the providers you import, and you don't need any build tags.

Pass the tags when building your application:

```bash
go build -tags lego_dnslight,lego_dns_cloudflare,lego_dns_pdns ./...
```

Use the same tags for `go test` and other commands or tools, so they see the same set of providers as your build.
