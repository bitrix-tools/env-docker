package dns01

import (
	"context"
	"crypto/rand"
	"crypto/rsa"
	"errors"
	"testing"
	"time"

	"github.com/go-acme/lego/v5/acme"
	"github.com/go-acme/lego/v5/acme/api"
	"github.com/go-acme/lego/v5/challenge"
	"github.com/go-acme/lego/v5/internal/tester"
	"github.com/go-acme/lego/v5/internal/tester/dnsmock"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

type providerMock struct {
	present, cleanUp error
}

func (p *providerMock) Present(_ context.Context, _, _, _ string) error { return p.present }
func (p *providerMock) CleanUp(_ context.Context, _, _, _ string) error { return p.cleanUp }

type providerTimeoutMock struct {
	present, cleanUp  error
	timeout, interval time.Duration
}

func (p *providerTimeoutMock) Present(_ context.Context, _, _, _ string) error { return p.present }
func (p *providerTimeoutMock) CleanUp(_ context.Context, _, _, _ string) error { return p.cleanUp }
func (p *providerTimeoutMock) Timeout() (time.Duration, time.Duration)         { return p.timeout, p.interval }

func TestChallenge_PreSolve(t *testing.T) {
	server := tester.MockACMEServer().BuildHTTPS(t)

	privateKey, err := rsa.GenerateKey(rand.Reader, 1024)
	require.NoError(t, err)

	core, err := api.New(server.Client(), "lego-test", server.URL+"/dir", "", privateKey)
	require.NoError(t, err)

	testCases := []struct {
		desc        string
		validate    ValidateFunc
		preCheck    WrapPreCheckFunc
		provider    challenge.Provider
		expectError bool
	}{
		{
			desc:     "success",
			validate: func(_ context.Context, _ *api.Core, _ string, _ acme.Challenge) error { return nil },
			preCheck: func(_ context.Context, _, _, _ string, _ PreCheckFunc) (bool, error) { return true, nil },
			provider: &providerMock{},
		},
		{
			desc:     "validate fail",
			validate: func(_ context.Context, _ *api.Core, _ string, _ acme.Challenge) error { return errors.New("OOPS") },
			preCheck: func(_ context.Context, _, _, _ string, _ PreCheckFunc) (bool, error) { return true, nil },
			provider: &providerMock{
				present: nil,
				cleanUp: nil,
			},
		},
		{
			desc:     "preCheck fail",
			validate: func(_ context.Context, _ *api.Core, _ string, _ acme.Challenge) error { return nil },
			preCheck: func(_ context.Context, _, _, _ string, _ PreCheckFunc) (bool, error) {
				return false, errors.New("OOPS")
			},
			provider: &providerTimeoutMock{
				timeout:  2 * time.Second,
				interval: 500 * time.Millisecond,
			},
		},
		{
			desc:     "present fail",
			validate: func(_ context.Context, _ *api.Core, _ string, _ acme.Challenge) error { return nil },
			preCheck: func(_ context.Context, _, _, _ string, _ PreCheckFunc) (bool, error) { return true, nil },
			provider: &providerMock{
				present: errors.New("OOPS"),
			},
			expectError: true,
		},
		{
			desc:     "cleanUp fail",
			validate: func(_ context.Context, _ *api.Core, _ string, _ acme.Challenge) error { return nil },
			preCheck: func(_ context.Context, _, _, _ string, _ PreCheckFunc) (bool, error) { return true, nil },
			provider: &providerMock{
				cleanUp: errors.New("OOPS"),
			},
		},
	}

	for _, test := range testCases {
		t.Run(test.desc, func(t *testing.T) {
			chlg := NewChallenge(core, test.validate, test.provider, WrapPreCheck(test.preCheck))

			authz := acme.Authorization{
				Identifier: acme.Identifier{
					Value: "example.com",
				},
				Challenges: []acme.Challenge{
					{Type: challenge.DNS01.String()},
				},
			}

			err = chlg.PreSolve(t.Context(), authz)
			if test.expectError {
				require.Error(t, err)
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestChallenge_Solve(t *testing.T) {
	mockDefault(t, dnsmock.NewServer().
		Query("_acme-challenge.example.com. CNAME", dnsmock.Noop).
		Build(t))

	server := tester.MockACMEServer().BuildHTTPS(t)

	privateKey, err := rsa.GenerateKey(rand.Reader, 1024)
	require.NoError(t, err)

	core, err := api.New(server.Client(), "lego-test", server.URL+"/dir", "", privateKey)
	require.NoError(t, err)

	testCases := []struct {
		desc        string
		validate    ValidateFunc
		preCheck    WrapPreCheckFunc
		provider    challenge.Provider
		expectError bool
	}{
		{
			desc:     "success",
			validate: func(_ context.Context, _ *api.Core, _ string, _ acme.Challenge) error { return nil },
			preCheck: func(_ context.Context, _, _, _ string, _ PreCheckFunc) (bool, error) { return true, nil },
			provider: &providerMock{},
		},
		{
			desc:     "validate fail",
			validate: func(_ context.Context, _ *api.Core, _ string, _ acme.Challenge) error { return errors.New("OOPS") },
			preCheck: func(_ context.Context, _, _, _ string, _ PreCheckFunc) (bool, error) { return true, nil },
			provider: &providerMock{
				present: nil,
				cleanUp: nil,
			},
			expectError: true,
		},
		{
			desc:     "preCheck fail",
			validate: func(_ context.Context, _ *api.Core, _ string, _ acme.Challenge) error { return nil },
			preCheck: func(_ context.Context, _, _, _ string, _ PreCheckFunc) (bool, error) {
				return false, errors.New("OOPS")
			},
			provider: &providerTimeoutMock{
				timeout:  2 * time.Second,
				interval: 500 * time.Millisecond,
			},
			expectError: true,
		},
		{
			desc:     "present fail",
			validate: func(_ context.Context, _ *api.Core, _ string, _ acme.Challenge) error { return nil },
			preCheck: func(_ context.Context, _, _, _ string, _ PreCheckFunc) (bool, error) { return true, nil },
			provider: &providerMock{
				present: errors.New("OOPS"),
			},
		},
		{
			desc:     "cleanUp fail",
			validate: func(_ context.Context, _ *api.Core, _ string, _ acme.Challenge) error { return nil },
			preCheck: func(_ context.Context, _, _, _ string, _ PreCheckFunc) (bool, error) { return true, nil },
			provider: &providerMock{
				cleanUp: errors.New("OOPS"),
			},
		},
	}

	for _, test := range testCases {
		t.Run(test.desc, func(t *testing.T) {
			var options []ChallengeOption
			if test.preCheck != nil {
				options = append(options, WrapPreCheck(test.preCheck))
			}

			chlg := NewChallenge(core, test.validate, test.provider, options...)

			authz := acme.Authorization{
				Identifier: acme.Identifier{
					Value: "example.com",
				},
				Challenges: []acme.Challenge{
					{Type: challenge.DNS01.String()},
				},
			}

			err = chlg.Solve(t.Context(), authz)
			if test.expectError {
				require.Error(t, err)
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestChallenge_CleanUp(t *testing.T) {
	server := tester.MockACMEServer().BuildHTTPS(t)

	privateKey, err := rsa.GenerateKey(rand.Reader, 1024)
	require.NoError(t, err)

	core, err := api.New(server.Client(), "lego-test", server.URL+"/dir", "", privateKey)
	require.NoError(t, err)

	testCases := []struct {
		desc        string
		validate    ValidateFunc
		preCheck    WrapPreCheckFunc
		provider    challenge.Provider
		expectError bool
	}{
		{
			desc:     "success",
			validate: func(_ context.Context, _ *api.Core, _ string, _ acme.Challenge) error { return nil },
			preCheck: func(_ context.Context, _, _, _ string, _ PreCheckFunc) (bool, error) { return true, nil },
			provider: &providerMock{},
		},
		{
			desc:     "validate fail",
			validate: func(_ context.Context, _ *api.Core, _ string, _ acme.Challenge) error { return errors.New("OOPS") },
			preCheck: func(_ context.Context, _, _, _ string, _ PreCheckFunc) (bool, error) { return true, nil },
			provider: &providerMock{
				present: nil,
				cleanUp: nil,
			},
		},
		{
			desc:     "preCheck fail",
			validate: func(_ context.Context, _ *api.Core, _ string, _ acme.Challenge) error { return nil },
			preCheck: func(_ context.Context, _, _, _ string, _ PreCheckFunc) (bool, error) {
				return false, errors.New("OOPS")
			},
			provider: &providerTimeoutMock{
				timeout:  2 * time.Second,
				interval: 500 * time.Millisecond,
			},
		},
		{
			desc:     "present fail",
			validate: func(_ context.Context, _ *api.Core, _ string, _ acme.Challenge) error { return nil },
			preCheck: func(_ context.Context, _, _, _ string, _ PreCheckFunc) (bool, error) { return true, nil },
			provider: &providerMock{
				present: errors.New("OOPS"),
			},
		},
		{
			desc:     "cleanUp fail",
			validate: func(_ context.Context, _ *api.Core, _ string, _ acme.Challenge) error { return nil },
			preCheck: func(_ context.Context, _, _, _ string, _ PreCheckFunc) (bool, error) { return true, nil },
			provider: &providerMock{
				cleanUp: errors.New("OOPS"),
			},
			expectError: true,
		},
	}

	for _, test := range testCases {
		t.Run(test.desc, func(t *testing.T) {
			chlg := NewChallenge(core, test.validate, test.provider, WrapPreCheck(test.preCheck))

			authz := acme.Authorization{
				Identifier: acme.Identifier{
					Value: "example.com",
				},
				Challenges: []acme.Challenge{
					{Type: challenge.DNS01.String()},
				},
			}

			err = chlg.CleanUp(t.Context(), authz)
			if test.expectError {
				require.Error(t, err)
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestGetChallengeInfo(t *testing.T) {
	mockDefault(t, dnsmock.NewServer().
		Query("_acme-challenge.example.com. CNAME", dnsmock.Noop).
		Build(t))

	info := GetChallengeInfo(t.Context(), "example.com", "123")

	expected := ChallengeInfo{
		FQDN:          "_acme-challenge.example.com.",
		EffectiveFQDN: "_acme-challenge.example.com.",
		Value:         "pmWkWSBCL51Bfkhn79xPuKBKHz__H6B-mY6G9_eieuM",
		Prefix:        "_acme-challenge",
	}

	assert.Equal(t, expected, info)
}

func TestGetChallengeInfo_cname(t *testing.T) {
	mockDefault(t, dnsmock.NewServer().
		Query("_acme-challenge.example.com. CNAME", dnsmock.CNAME("example.org.")).
		Query("example.org. CNAME", dnsmock.Noop).
		Build(t))

	info := GetChallengeInfo(t.Context(), "example.com", "123")

	expected := ChallengeInfo{
		FQDN:          "_acme-challenge.example.com.",
		EffectiveFQDN: "example.org.",
		Value:         "pmWkWSBCL51Bfkhn79xPuKBKHz__H6B-mY6G9_eieuM",
		Prefix:        "_acme-challenge",
	}

	assert.Equal(t, expected, info)
}

func TestGetChallengeInfo_cname_disabled(t *testing.T) {
	mockDefault(t, dnsmock.NewServer().
		// Never called when the env var works.
		Query("_acme-challenge.example.com. CNAME", dnsmock.CNAME("example.org.")).
		Build(t))

	t.Setenv("LEGO_DISABLE_CNAME_SUPPORT", "true")

	info := GetChallengeInfo(t.Context(), "example.com", "123")

	expected := ChallengeInfo{
		FQDN:          "_acme-challenge.example.com.",
		EffectiveFQDN: "_acme-challenge.example.com.",
		Value:         "pmWkWSBCL51Bfkhn79xPuKBKHz__H6B-mY6G9_eieuM",
		Prefix:        "_acme-challenge",
	}

	assert.Equal(t, expected, info)
}

func TestGetChallengeInfo_Domain(t *testing.T) {
	mockDefault(t, dnsmock.NewServer().
		Query("_acme-challenge.example.com. CNAME", dnsmock.Noop).
		Build(t))

	info := GetChallengeInfo(t.Context(), "example.com", "123")

	assert.Equal(t, "example.com.", info.Domain())
}

func TestGetChallengeInfo_EffectiveDomain(t *testing.T) {
	mockDefault(t, dnsmock.NewServer().
		Query("_acme-challenge.example.com. CNAME", dnsmock.Noop).
		Build(t))

	info := GetChallengeInfo(t.Context(), "example.com", "123")

	assert.Equal(t, "example.com.", info.EffectiveDomain())
}

func TestGetChallengeInfo_EffectiveDomain_cname(t *testing.T) {
	mockDefault(t, dnsmock.NewServer().
		Query("_acme-challenge.example.com. CNAME", dnsmock.CNAME("_acme-challenge.example.org.")).
		Query("_acme-challenge.example.org. CNAME", dnsmock.Noop).
		Build(t))

	info := GetChallengeInfo(t.Context(), "example.com", "123")

	assert.Equal(t, "_acme-challenge.example.org.", info.EffectiveDomain())
}
