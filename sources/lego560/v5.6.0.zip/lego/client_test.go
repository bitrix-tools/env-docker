package lego

import (
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"testing"

	"github.com/go-acme/lego/v5/acme"
	"github.com/go-acme/lego/v5/internal/tester"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestNewClient(t *testing.T) {
	server := tester.MockACMEServer().BuildHTTPS(t)

	key, err := rsa.GenerateKey(rand.Reader, 1024)
	require.NoError(t, err, "Could not generate test key")

	user := mockUser{
		email:      "test@test.com",
		regres:     new(acme.ExtendedAccount),
		privatekey: key,
	}

	config := NewConfig(user)
	config.CADirURL = server.URL + "/dir"
	config.HTTPClient = server.Client()

	client, err := NewClient(config)
	require.NoError(t, err, "Could not create client")

	assert.NotNil(t, client)
}

type mockUser struct {
	email      string
	regres     *acme.ExtendedAccount
	privatekey *rsa.PrivateKey
}

func (u mockUser) GetEmail() string                       { return u.email }
func (u mockUser) GetRegistration() *acme.ExtendedAccount { return u.regres }
func (u mockUser) GetPrivateKey() crypto.Signer           { return u.privatekey }
