package api

import (
	"context"
	"errors"

	"github.com/go-acme/lego/v5/acme"
	"github.com/go-acme/lego/v5/acme/api/internal/sender"
)

type ChallengeService service

// New Creates a challenge.
func (c *ChallengeService) New(ctx context.Context, chlgURL string) (acme.ExtendedChallenge, error) {
	if chlgURL == "" {
		return acme.ExtendedChallenge{}, errors.New("challenge[new]: empty URL")
	}

	// Challenge initiation is done by sending a JWS payload containing the trivial JSON object `{}`.
	// We use an empty struct instance as the postJSON payload here to achieve this result.
	var chlng acme.ExtendedChallenge

	resp, err := c.core.post(ctx, chlgURL, struct{}{}, &chlng)
	if err != nil {
		return acme.ExtendedChallenge{}, err
	}

	chlng.AuthorizationURL = sender.GetLink(resp.Header, "up")
	chlng.RetryAfter = sender.GetRetryAfter(resp)

	return chlng, nil
}

// Get Gets a challenge.
func (c *ChallengeService) Get(ctx context.Context, chlgURL string) (acme.ExtendedChallenge, error) {
	if chlgURL == "" {
		return acme.ExtendedChallenge{}, errors.New("challenge[get]: empty URL")
	}

	var chlng acme.ExtendedChallenge

	resp, err := c.core.postAsGet(ctx, chlgURL, &chlng)
	if err != nil {
		return acme.ExtendedChallenge{}, err
	}

	chlng.AuthorizationURL = sender.GetLink(resp.Header, "up")
	chlng.RetryAfter = sender.GetRetryAfter(resp)

	return chlng, nil
}
