module github.com/go-acme/lego/v5

go 1.26.0

ignore ./docs

require (
	cloud.google.com/go/compute/metadata v0.10.0
	github.com/Azure/azure-sdk-for-go/sdk/azcore v1.23.3
	github.com/Azure/azure-sdk-for-go/sdk/azidentity v1.15.0
	github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/dns/armdns v1.2.0
	github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/privatedns/armprivatedns/v2 v2.0.0
	github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/resourcegraph/armresourcegraph v0.10.0
	github.com/BurntSushi/toml v1.6.0
	github.com/Myra-Security-GmbH/myrasec-go/v2 v2.62.1
	github.com/akamai/AkamaiOPEN-edgegrid-golang/v14 v14.1.0
	github.com/alibabacloud-go/darabonba-openapi/v2 v2.2.4
	github.com/alibabacloud-go/tea v1.5.3
	github.com/aliyun/credentials-go v1.4.7
	github.com/aws/aws-sdk-go-v2 v1.47.5
	github.com/aws/aws-sdk-go-v2/config v1.33.12
	github.com/aws/aws-sdk-go-v2/credentials v1.20.12
	github.com/aws/aws-sdk-go-v2/service/lightsail v1.69.0
	github.com/aws/aws-sdk-go-v2/service/route53 v1.70.6
	github.com/aws/aws-sdk-go-v2/service/s3 v1.114.6
	github.com/aws/aws-sdk-go-v2/service/sts v1.51.6
	github.com/aziontech/azionapi-go-sdk v0.148.0
	github.com/baidubce/bce-sdk-go v0.9.277
	github.com/bodgit/tsig v1.3.1
	github.com/bradfitz/gomemcache v0.0.0-20260422231931-4d751bb6e37c
	github.com/cenkalti/backoff/v5 v5.0.3
	github.com/dnsimple/dnsimple-go/v10 v10.0.0
	github.com/exoscale/egoscale/v3 v3.1.61
	github.com/go-acme/alidns-20150109/v5 v5.6.1
	github.com/go-acme/esa-20240910/v3 v3.14.0
	github.com/go-acme/jdcloud-sdk-go v1.64.0
	github.com/go-acme/tencentclouddnspod v1.3.131
	github.com/go-acme/tencentedgdeone v1.3.186
	github.com/go-jose/go-jose/v4 v4.1.6
	github.com/go-viper/mapstructure/v2 v2.5.0
	github.com/google/go-cmp v0.7.0
	github.com/google/go-querystring v1.2.0
	github.com/google/uuid v1.6.0
	github.com/gophercloud/gophercloud/v2 v2.15.0
	github.com/gophercloud/utils/v2 v2.0.0-20260922174841-b4759ea0529b
	github.com/hashicorp/go-retryablehttp v0.7.8
	github.com/hashicorp/go-version v1.9.0
	github.com/huaweicloud/huaweicloud-sdk-go-v3 v0.1.220
	github.com/infobloxopen/infoblox-go-client/v2 v2.12.0
	github.com/joho/godotenv v1.5.1
	github.com/labbsr0x/bindman-dns-webhook v1.0.2
	github.com/ldez/grignotin v0.10.1
	github.com/linode/linodego/v2 v2.10.0
	github.com/liquidweb/liquidweb-go v1.6.4
	github.com/mattn/go-isatty v0.0.24
	github.com/mattn/go-zglob v0.0.8
	github.com/miekg/dns v1.1.73
	github.com/mimuret/golang-iij-dpf v0.9.1
	github.com/namedotcom/go/v4 v4.0.2
	github.com/nrdcg/auroradns v1.2.0
	github.com/nrdcg/bunny-go v0.1.0
	github.com/nrdcg/desec v0.11.3
	github.com/nrdcg/freemyip v0.3.0
	github.com/nrdcg/goacmedns v0.2.0
	github.com/nrdcg/goinwx v0.12.0
	github.com/nrdcg/mailinabox v0.3.0
	github.com/nrdcg/namesilo v0.5.0
	github.com/nrdcg/nodion v0.1.0
	github.com/nrdcg/oci-go-sdk/common/v1065 v1065.128.0
	github.com/nrdcg/oci-go-sdk/dns/v1065 v1065.128.0
	github.com/nrdcg/porkbun v0.4.0
	github.com/nrdcg/vegadns v0.3.0
	github.com/nzdjb/go-metaname v1.0.0
	github.com/ovh/go-ovh v1.9.0
	github.com/pquerna/otp v1.5.0
	github.com/regfish/regfish-dnsapi-go v0.2.0
	github.com/sacloud/sacloud-sdk-go v0.4.0
	github.com/scaleway/scaleway-sdk-go v1.39.0
	github.com/selectel/domains-go v1.1.0
	github.com/selectel/go-selvpcclient/v5 v5.0.0
	github.com/softlayer/softlayer-go v1.2.1
	github.com/stretchr/testify v1.12.1
	github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/common v1.3.202
	github.com/transip/gotransip/v6 v6.28.0
	github.com/ucloud/ucloud-sdk-go v0.22.141
	github.com/ultradns/ultradns-go-sdk v1.8.6-20261009044533-535b847
	github.com/urfave/cli/v3 v3.14.0
	github.com/vinyldns/go-vinyldns v0.9.18
	github.com/volcengine/volc-sdk-golang v1.0.258
	github.com/vultr/govultr/v3 v3.33.2
	github.com/yandex-cloud/go-genproto v0.133.0
	github.com/yandex-cloud/go-sdk/services/dns v0.0.106
	github.com/yandex-cloud/go-sdk/v2 v2.185.0
	gitlab.com/greyxor/slogor v1.7.1
	golang.org/x/crypto v0.58.0
	golang.org/x/net v0.62.0
	golang.org/x/oauth2 v0.37.0
	golang.org/x/text v0.43.0
	golang.org/x/time v0.16.0
	google.golang.org/api v0.309.0
	gopkg.in/ns1/ns1-go.v2 v2.18.0
	gopkg.in/yaml.v3 v3.0.1
	software.sslmate.com/src/go-pkcs12 v0.7.4
)

require (
	cloud.google.com/go/auth v0.24.1-0.20261001053825-dbc26066f70a // indirect
	cloud.google.com/go/auth/oauth2adapt v0.3.0 // indirect
	github.com/AdamSLevy/jsonrpc2/v14 v14.1.0 // indirect
	github.com/Azure/azure-sdk-for-go/sdk/internal v1.13.0 // indirect
	github.com/AzureAD/microsoft-authentication-library-for-go v1.10.1 // indirect
	github.com/Myra-Security-GmbH/signature v1.1.0 // indirect
	github.com/alexbrainman/sspi v0.0.0-20250919150558-7d374ff0d59e // indirect
	github.com/alibabacloud-go/alibabacloud-gateway-spi v0.0.5 // indirect
	github.com/alibabacloud-go/debug v1.0.1 // indirect
	github.com/alibabacloud-go/openapi-util v0.1.2 // indirect
	github.com/alibabacloud-go/tea-utils/v2 v2.0.9 // indirect
	github.com/aws/aws-sdk-go-v2/aws/protocol/eventstream v1.7.25 // indirect
	github.com/aws/aws-sdk-go-v2/feature/ec2/imds v1.20.5 // indirect
	github.com/aws/aws-sdk-go-v2/internal/configsources v1.5.8 // indirect
	github.com/aws/aws-sdk-go-v2/internal/endpoints/v2 v2.8.8 // indirect
	github.com/aws/aws-sdk-go-v2/internal/v4a v1.5.8 // indirect
	github.com/aws/aws-sdk-go-v2/service/internal/accept-encoding v1.13.23 // indirect
	github.com/aws/aws-sdk-go-v2/service/internal/checksum v1.11.9 // indirect
	github.com/aws/aws-sdk-go-v2/service/internal/presigned-url v1.14.8 // indirect
	github.com/aws/aws-sdk-go-v2/service/internal/s3shared v1.20.8 // indirect
	github.com/aws/aws-sdk-go-v2/service/signin v1.12.0 // indirect
	github.com/aws/aws-sdk-go-v2/service/sso v1.39.0 // indirect
	github.com/aws/aws-sdk-go-v2/service/ssooidc v1.44.0 // indirect
	github.com/aws/smithy-go v1.28.7 // indirect
	github.com/benbjohnson/clock v1.3.5 // indirect
	github.com/bodgit/gssapi v0.0.4 // indirect
	github.com/boombuler/barcode v1.0.1 // indirect
	github.com/cenkalti/backoff/v4 v4.3.0 // indirect
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/clbanning/mxj/v2 v2.7.0 // indirect
	github.com/fatih/structs v1.1.0 // indirect
	github.com/felixge/httpsnoop v1.1.0 // indirect
	github.com/fsnotify/fsnotify v1.10.1 // indirect
	github.com/gabriel-vasile/mimetype v1.4.16 // indirect
	github.com/ghodss/yaml v1.0.0 // indirect
	github.com/go-errors/errors v1.0.1 // indirect
	github.com/go-logr/logr v1.4.4 // indirect
	github.com/go-logr/stdr v1.2.2 // indirect
	github.com/go-ozzo/ozzo-validation/v4 v4.5.0 // indirect
	github.com/go-playground/locales v0.14.2 // indirect
	github.com/go-playground/universal-translator v0.18.2 // indirect
	github.com/go-playground/validator/v10 v10.30.5 // indirect
	github.com/goccy/go-yaml v1.19.2 // indirect
	github.com/gofrs/flock v0.13.1 // indirect
	github.com/gofrs/uuid v4.4.0+incompatible // indirect
	github.com/gofrs/uuid/v5 v5.5.1 // indirect
	github.com/golang-jwt/jwt/v4 v4.5.2 // indirect
	github.com/golang-jwt/jwt/v5 v5.3.1 // indirect
	github.com/golang/protobuf v1.5.4 // indirect
	github.com/google/s2a-go v0.1.11 // indirect
	github.com/googleapis/enterprise-certificate-proxy v0.3.24 // indirect
	github.com/googleapis/gax-go/v2 v2.26.2 // indirect
	github.com/gophercloud/gophercloud v1.14.1 // indirect
	github.com/gorilla/websocket v1.5.3 // indirect
	github.com/hashicorp/errwrap v1.0.0 // indirect
	github.com/hashicorp/go-cleanhttp v0.5.2 // indirect
	github.com/hashicorp/go-multierror v1.1.1 // indirect
	github.com/hashicorp/go-uuid v1.0.4 // indirect
	github.com/hashicorp/hcl v1.0.0 // indirect
	github.com/jcmturner/aescts/v2 v2.0.0 // indirect
	github.com/jcmturner/dnsutils/v2 v2.0.0 // indirect
	github.com/jcmturner/gofork v1.7.6 // indirect
	github.com/jcmturner/goidentity/v6 v6.0.1 // indirect
	github.com/jcmturner/gokrb5/v8 v8.4.4 // indirect
	github.com/jcmturner/rpc/v2 v2.0.3 // indirect
	github.com/json-iterator/go v1.1.13-0.20220915233716-71ac16282d12 // indirect
	github.com/k0kubun/go-ansi v0.0.0-20180517002512-3bf9e2903213 // indirect
	github.com/kolo/xmlrpc v0.0.0-20220921171641-a4b6fa1dd06b // indirect
	github.com/kylelemons/godebug v1.1.0 // indirect
	github.com/labbsr0x/goh v1.0.1 // indirect
	github.com/leodido/go-urn v1.5.0 // indirect
	github.com/liquidweb/liquidweb-cli v0.6.10 // indirect
	github.com/magiconair/properties v1.18.12 // indirect
	github.com/mitchellh/go-homedir v1.1.0 // indirect
	github.com/mitchellh/mapstructure v1.5.0 // indirect
	github.com/modern-go/concurrent v0.0.0-20180306012644-bacd9c7ef1dd // indirect
	github.com/modern-go/reflect2 v1.0.3-0.20250322232337-35a7c28c31ee // indirect
	github.com/openshift/gssapi v0.0.0-20161010215902-5fb4217df13b // indirect
	github.com/pelletier/go-toml/v2 v2.4.3 // indirect
	github.com/peterhellberg/link v1.2.0 // indirect
	github.com/pkg/browser v0.0.0-20240102092130-5ac0b6a4141c // indirect
	github.com/pkg/errors v0.9.1 // indirect
	github.com/sagikazarmark/locafero v0.4.0 // indirect
	github.com/sagikazarmark/slog-shim v0.1.0 // indirect
	github.com/shopspring/decimal v1.4.0 // indirect
	github.com/sirupsen/logrus v1.10.2 // indirect
	github.com/softlayer/xmlrpc v0.0.0-20200409220501-5f089df7cb7e // indirect
	github.com/sony/gobreaker/v2 v2.4.0 // indirect
	github.com/sourcegraph/conc v0.3.0 // indirect
	github.com/spf13/afero v1.15.0 // indirect
	github.com/spf13/cast v1.10.0 // indirect
	github.com/spf13/pflag v1.0.10 // indirect
	github.com/spf13/viper v1.18.2 // indirect
	github.com/stretchr/objx v0.5.3 // indirect
	github.com/subosito/gotenv v1.6.0 // indirect
	github.com/tjfoc/gmsm v1.4.1 // indirect
	github.com/youmark/pkcs8 v0.0.0-20240726163527-a2c0da244d78 // indirect
	go.mongodb.org/mongo-driver v1.17.10 // indirect
	go.opentelemetry.io/auto/sdk v1.2.1 // indirect
	go.opentelemetry.io/contrib/instrumentation/net/http/otelhttp v0.69.0 // indirect
	go.opentelemetry.io/otel v1.45.0 // indirect
	go.opentelemetry.io/otel/metric v1.45.0 // indirect
	go.opentelemetry.io/otel/trace v1.45.0 // indirect
	go.uber.org/multierr v1.11.0 // indirect
	go.uber.org/ratelimit v0.3.1 // indirect
	go.uber.org/zap v1.28.0 // indirect
	go.yaml.in/yaml/v3 v3.0.5 // indirect
	golang.org/x/exp v0.0.0-20260410095643-746e56fc9e2f // indirect
	golang.org/x/sync v0.24.0 // indirect
	golang.org/x/sys v0.49.0 // indirect
	google.golang.org/genproto/googleapis/api v0.0.0-20260715232425-e75dac1f907d // indirect
	google.golang.org/genproto/googleapis/rpc v0.0.0-20261019180522-ce908d29299b // indirect
	google.golang.org/grpc v1.84.0 // indirect
	google.golang.org/protobuf v1.36.12 // indirect
	gopkg.in/ini.v1 v1.67.3 // indirect
	gopkg.in/yaml.v2 v2.4.0 // indirect
)
